using BhaskaraApp;
using System.Data;
namespace TesteBhaskara
{
    [TestClass]
    public class CalculandoUnitTest
    {
        private Bhaskara bhaskara;

        [TestInitialize]
        public void Inicializar()
        {
            bhaskara = new Bhaskara(1, -3, 2);
        }

        [TestMethod]
        [DataRow(1.0, -6.0, 8.0, 4.0)]
        [DataRow(2.0, -7.0, 3.0, 25.0)]
        [DataRow(5.0, 2.0, -3.0, 64.0)]
        [DataRow(1.0, 2.0, 5.0, -16.0)]
        [DataRow(0.0, 0.0, 0.0, 0.0)]

        public void TesteCalcularDelta(double a, double b, double c, double esperado)
        {
            bhaskara = new Bhaskara(a, b, c);
            double obtido = bhaskara.CalcularDelta();

            Assert.AreEqual(esperado, obtido);
        }


        [TestMethod]
        [DataRow(1.0, -6.0, 8.0, true)]
        [DataRow(2.0, -7.0, 3.0, true)]
        [DataRow(5.0, 2.0, -3.0, true)]
        [DataRow(1.0, 2.0, 5.0, false)]
        [DataRow(0.0, 0.0, 0.0, false)]
        public void TemRaizesReais(double a, double b, double c, bool esperado)
        {
            bhaskara = new Bhaskara(a, b, c);
            bool obtido = bhaskara.TemRaizesReais();
            Assert.AreEqual(esperado, obtido);
        }


        [TestMethod]
          [DataRow(3.0, -11.0, 6.0, 3.0, 0.6667)]
          [DataRow(1.0, -6.0, 9.0, 3.0, 3.0)]
          [DataRow(1.0, 4.0, -5.0, 1.0, -5.0)]
          [DataRow(1.0, 1.0, 2.0, null, null)]
          [DataRow(0.0, 0.0, 0.0, null, null)]
        public void TestarCalcularRaizes(double a, double b, double c, double? x1, double? x2)
        {
            bhaskara = new Bhaskara(a, b, c);
            var (raiz1, raiz2) = bhaskara.CalcularRaizes();

            bool iguais = ($"{x1:F3}" == $"{raiz1:F3}") && ($"{x2:F3}" == $"{raiz2:F3}");
            Assert.IsTrue(iguais);

        }




    }
}